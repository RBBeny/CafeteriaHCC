﻿namespace CafeteriaHCC.Models
{
    public class MesaOrdenes
    {
        public int MesaId { get; set; }
        public int TotalOrdenes { get; set; }
    }
}