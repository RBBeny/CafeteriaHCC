﻿namespace CafeteriaHCC.Models.Respuestas
{
    public class RespuestaApi
    {
        public int Estatus { get; set; }
        public string Mensaje { get; set; }
        public int Codigo { get; set; }
    }
}
